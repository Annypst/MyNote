package simplefactory;

public class Xiaomi implements TV{
    @Override
    public void play() {
        System.out.println("Xiaomi playing");
    }
}
