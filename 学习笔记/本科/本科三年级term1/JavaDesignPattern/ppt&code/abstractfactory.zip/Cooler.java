package abstractfactory;

public interface Cooler {
    public void cool();
}
