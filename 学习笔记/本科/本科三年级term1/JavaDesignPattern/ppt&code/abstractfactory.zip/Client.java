package abstractfactory;

public class Client
{
	public static void main(String args[])
	{

         try
         {
         	EFactory factory;
         	Television tv;
         	AirConditioner ac;
			 Cooler cooler;

         	factory=(EFactory)XMLUtil.getBean();
         	tv=factory.produceTelevision();
         	tv.play();
         	ac=factory.produceAirConditioner();
         	ac.changeTemperature();
			 cooler=factory.produceCooler();
			 cooler.cool();

         }
         catch(Exception e)
         {
         	System.out.println(e.getMessage());
         }
	}
}
