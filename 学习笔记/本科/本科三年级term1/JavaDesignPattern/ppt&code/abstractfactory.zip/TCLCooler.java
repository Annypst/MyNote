package abstractfactory;

public class TCLCooler implements Cooler{
    @Override
    public void cool() {
        System.out.println("TCL冰箱制冷中");
    }
}
