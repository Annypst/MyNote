package abstractfactory;

public class TCLFactory implements EFactory
{
	public Television produceTelevision()
	{
		return new TCLTelevision();
	}
	
	public AirConditioner produceAirConditioner()
	{
		return new TCLAirConditioner();
	}

	@Override
	public Cooler produceCooler() {
		return new TCLCooler();
	}
}