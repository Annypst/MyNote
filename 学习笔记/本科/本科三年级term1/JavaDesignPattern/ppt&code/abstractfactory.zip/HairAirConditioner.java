package abstractfactory;

public class HairAirConditioner implements AirConditioner
{
	public void changeTemperature()
	{
		System.out.println("海尔空调启动中......");
	}
}