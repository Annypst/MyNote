package abstractfactory;

public class XiaomiTV implements Television{
    @Override
    public void play() {
        System.out.println("小米电视播放中");
    }
}
