package abstractfactory;

public interface EFactory
{
	public Television produceTelevision();
	public AirConditioner produceAirConditioner();
	public Cooler produceCooler();


}