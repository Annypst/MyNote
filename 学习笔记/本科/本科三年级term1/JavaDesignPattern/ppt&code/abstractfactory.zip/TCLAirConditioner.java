package abstractfactory;

public class TCLAirConditioner implements AirConditioner
{
	public void changeTemperature()
	{
		System.out.println("TCL空调启动中......");
	}
}