package abstractfactory;

public class XiaomiCooler implements Cooler{
    @Override
    public void cool() {
        System.out.println("小米冰箱制冷中");
    }
}
