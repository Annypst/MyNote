package abstractfactory;

public class HaierTelevision implements Television
{
	public void play()
	{
		System.out.println("海尔电视播放中.......");
	}
}