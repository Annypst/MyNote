package abstractfactory;

public class XiaomiFactory implements EFactory{
    @Override
    public Television produceTelevision() {
        return new XiaomiTV();
    }

    @Override
    public AirConditioner produceAirConditioner() {
        return new XiaomiAC();
    }

    @Override
    public Cooler produceCooler() {
        return new XiaomiCooler();
    }
}
