package abstractfactory;

public class XiaomiAC implements AirConditioner{
    @Override
    public void changeTemperature() {
        System.out.println("小米空调运行中");
    }
}
