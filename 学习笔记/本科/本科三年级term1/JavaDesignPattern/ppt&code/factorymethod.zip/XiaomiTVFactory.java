package factorymethod;

public class XiaomiTVFactory implements TVFactory{
    @Override
    public TV produceTV() {
        System.out.println("С�׵���������");
        return new XiaomiTV();
    }
}
